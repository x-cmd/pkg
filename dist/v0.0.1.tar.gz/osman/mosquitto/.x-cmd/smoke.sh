# shellcheck shell=dash

# if ! mosquitto -h ;then
#     pkg:error "fail to get version"
#     return 1
# fi
