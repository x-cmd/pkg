# shellcheck shell=dash

___x_cmd___hook_hurl_populate(){
    if [ "$___X_CMD_PKG___META_OS" = "win" ];then
        local archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
        mkdir -p "$archive_path/bin"
        touch "$archive_path/bin/hurl.exe" "$archive_path/bin/hurlfmt.exe"
        ln -sf "$archive_path/hurl.exe" "$archive_path/bin/hurl.exe"
        ln -sf "$archive_path/hurlfmt.exe" "$archive_path/bin/hurlfmt.exe"
    fi
}

___x_cmd___hook_hurl_populate