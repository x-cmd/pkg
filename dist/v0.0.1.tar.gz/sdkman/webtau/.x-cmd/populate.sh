# shellcheck    shell=sh            disable=SC3043,2154
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/webtau" "$___X_CMD_PKG___META_TGT/bin/webtau"
x mv "$___X_CMD_PKG___META_TGT/webtau.cmd" "$___X_CMD_PKG___META_TGT/bin/webtau.cmd"