# shellcheck shell=dash

chmod +x "$___X_CMD_PKG___META_TGT/bin/mvnd"