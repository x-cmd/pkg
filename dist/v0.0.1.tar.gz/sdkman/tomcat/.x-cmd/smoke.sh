# shellcheck shell=dash

x env use java

# if ! tomcat --version 2>&1;then
#     pkg:error "fail to get version"
#     return 1
# fi

if ! ~/.x-cmd.root/local/data/pkg/populate/tomcat/10.1.8/bin/version.sh 2>&1;then
    pkg:error "fail to get version"
    return 1
fi
