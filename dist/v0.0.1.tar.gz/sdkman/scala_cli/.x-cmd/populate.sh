# shellcheck    shell=sh            disable=SC3043,2154
if [ "$(x os name)" != "win" ]; then
    mkdir -p "$___X_CMD_PKG___META_TGT/bin"
    mv "$___X_CMD_PKG___META_TGT/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}" "$___X_CMD_PKG___META_TGT/bin/scala_cli"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/scala_cli"
else
    mv "$___X_CMD_PKG___META_TGT/scala-cli.exe" "$___X_CMD_PKG___META_TGT/scala_cli.exe"
fi
