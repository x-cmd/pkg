# shellcheck    shell=sh            disable=SC3043,2154
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/znai" "$___X_CMD_PKG___META_TGT/bin/znai"
x mv "$___X_CMD_PKG___META_TGT/znai-gen" "$___X_CMD_PKG___META_TGT/bin/znai-gen"
x mv "$___X_CMD_PKG___META_TGT/znai.cmd" "$___X_CMD_PKG___META_TGT/bin/znai.cmd"
