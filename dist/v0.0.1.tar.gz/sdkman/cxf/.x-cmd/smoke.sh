# shellcheck shell=dash
test_cxf_envpath(){
    local version="4.0.0"

    x path | grep -q ".x-cmd.root/local/data/pkg/populate/cxf/${version}/bin" || {
        pkg:error "Test path failed"
        return 1
    }
}
test_cxf_envpath