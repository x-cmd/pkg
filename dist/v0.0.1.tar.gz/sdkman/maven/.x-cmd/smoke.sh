# shellcheck shell=dash

# check the --version
x env try java
if ! mvn --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi