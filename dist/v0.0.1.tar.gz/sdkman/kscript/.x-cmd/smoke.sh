# shellcheck shell=dash

# check the --version
x env try java
x env try kotlin
if ! kscript --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi
