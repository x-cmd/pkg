# shellcheck shell=dash

# check the --version
x env try java=15.0.2
conc << EOF
/exit
EOF
if ! [ $? -eq 0 ] ;then
    pkg:error "fail to get version"
    return 1
fi
