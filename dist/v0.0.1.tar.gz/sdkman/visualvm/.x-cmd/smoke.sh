# shellcheck shell=dash
x env try java
output=$(visualvm --help)

if [ -n "$output" ];then
    return 0
else
    return 1
fi
