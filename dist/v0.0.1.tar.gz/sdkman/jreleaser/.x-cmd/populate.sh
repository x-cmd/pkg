# shellcheck shell=dash
# x env try java
# x pkg link java "$(x pkg default_version java)" "$___X_CMD_PKG___META_TGT/$___X_CMD_PKG___META_VERSION/bin"