# shellcheck shell=dash

# check the --version
x env try java
if ! ki --version 2>&1;then
    pkg:error "fail to get version"
    return 1
fi
