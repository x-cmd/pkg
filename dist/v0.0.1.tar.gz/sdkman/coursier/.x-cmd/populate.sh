# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
___x_cmd_pkg_coursier_populate(){
    mkdir -p "$___X_CMD_PKG___META_TGT/bin"

    local os="$(___x_cmd_pkg___attr_code coursier "$___X_CMD_PKG___META_VERSION" "$osarch" _os)"
    local arch="$(___x_cmd_pkg___attr_code coursier "$___X_CMD_PKG___META_VERSION" "$osarch" _arch)"
    local _os="$(echo "$os" | cut -d"'" -f2)"
    local _arch="$(echo "$arch" | cut -d"'" -f2)"
    x mv "$___X_CMD_PKG___META_TGT/cs-$_arch-$_os" "$___X_CMD_PKG___META_TGT/bin/coursier"

    chmod +x "$___X_CMD_PKG___META_TGT/bin/coursier"
}

___x_cmd_pkg_coursier_populate
