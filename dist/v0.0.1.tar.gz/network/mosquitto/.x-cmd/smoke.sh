# shellcheck shell=dash

# if ! mosquitto -d ;then
#     pkg:error "fail to get version"
#     return 1
# fi

return 1