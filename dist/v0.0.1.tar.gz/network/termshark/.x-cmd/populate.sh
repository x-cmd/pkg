# shellcheck shell=dash
pkg:info "Please ensure tshark is installed before use."
