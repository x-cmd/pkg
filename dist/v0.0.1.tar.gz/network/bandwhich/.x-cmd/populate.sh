# shellcheck    shell=sh            disable=SC3043,2154,2034,2155,1017
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
mv "$___X_CMD_PKG___META_TGT/bandwhich" "$___X_CMD_PKG___META_TGT/bin"
