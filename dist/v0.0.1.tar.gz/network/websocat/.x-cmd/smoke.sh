# shellcheck shell=dash

if ! websocat --help ;then
    pkg:error "fail to get version"
    return 1
fi
