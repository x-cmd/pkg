# shellcheck shell=dash
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = "win" ] ; then
    x mv "$___X_CMD_PKG___META_TGT/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.exe" "$___X_CMD_PKG___META_TGT/bin/websocat.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/websocat.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}" "$___X_CMD_PKG___META_TGT/bin/websocat"
fi