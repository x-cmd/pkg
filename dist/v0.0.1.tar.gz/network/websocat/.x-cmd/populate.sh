# shellcheck shell=dash
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/websocat.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}" "$___X_CMD_PKG___META_TGT/bin/websocat"