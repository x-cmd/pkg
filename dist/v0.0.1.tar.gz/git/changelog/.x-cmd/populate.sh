# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
x mv "$___X_CMD_PKG___META_TGT/changelog.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}" "$___X_CMD_PKG___META_TGT/changelog"