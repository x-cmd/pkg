mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/pdfcpu" "$___X_CMD_PKG___META_TGT/bin/pdfcpu"