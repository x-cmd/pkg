# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
x mv "$___X_CMD_PKG___META_TGT/magick_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}/bin" "$___X_CMD_PKG___META_TGT/"
chmod +x "$___X_CMD_PKG___META_TGT/bin/magick"