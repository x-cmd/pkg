___x_cmd_pkg_rust_populate(){
    (
        local tgt="$___X_CMD_PKG_POPULATE_PATH/$name/$version"

        if ! x cd "$tgt/"; then
            pkg:warn "can't enter into $tgt"
            return 1
        fi
        ./install.sh --destdir="../$version/" --prefix=/
        # cd .. && x rmrf "$tgt"
        # x rmrf "$___X_CMD_PKG_DOWNLOAD_PATH/$name/$version"
    )
}

___x_cmd_pkg_rust_populate
