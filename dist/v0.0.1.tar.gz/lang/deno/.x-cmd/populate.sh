# shellcheck    shell=sh            disable=SC3043,2154
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/deno" "$___X_CMD_PKG___META_TGT/bin/deno"