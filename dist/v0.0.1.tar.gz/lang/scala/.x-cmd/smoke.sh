# shellcheck shell=dash

# check the --version
x env try java
if ! scala --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi