# shellcheck shell=dash
export NPM_CONFIG_PREFIX="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm"
___x_cmd_pkg_node_boot(){
    local has_add_folder_command
    has_add_folder_command="$(type ___x_cmd_path_add_folder  2>/dev/null)"
    if [ -n "$has_add_folder_command" ]; then
        x path add_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/lib"
        x path add_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/bin"
    elif [ -d "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/lib" ];then
        x path add_existed_folder  "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/lib"
        x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/bin"
    else
        x path unshift "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/lib"
        x path unshift "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/bin"
    fi
}

___x_cmd_pkg_node_boot