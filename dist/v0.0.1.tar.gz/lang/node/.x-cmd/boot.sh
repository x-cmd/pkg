# shellcheck shell=dash
export NPM_CONFIG_PREFIX="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm"
___x_cmd_pkg_node_boot(){
    x path unshift "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/lib"
    x path unshift "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/bin"

}

___x_cmd_pkg_node_boot