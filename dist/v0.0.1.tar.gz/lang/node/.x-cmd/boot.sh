# shellcheck shell=dash
export NPM_CONFIG_PREFIX="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm"
___x_cmd_path_unshift "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.npm/bin"
