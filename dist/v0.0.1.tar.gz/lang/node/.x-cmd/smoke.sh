# shellcheck shell=dash

# check the --version
if ! node --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi

test_node_boot(){
    local test_NPM_CONFIG_PREFIX="${NPM_CONFIG_PREFIX%/*}"
    local candidate_version="${test_NPM_CONFIG_PREFIX#"${___X_CMD_PKG_POPULATE_PATH}/"*}"
    local candidate="${candidate_version%/*}"
    local version="${candidate_version#*/}"

    if [ -n "$candidate" ] && [ -n "$version" ] && [ -n "$candidate_version" ];then
        return 0
    else
        pkg:error "Test boot failed "
        return 1
    fi
}

test_node_boot
