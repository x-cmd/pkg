# shellcheck shell=dash

# check the --version
if ! go version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi


test_gopath_boot(){
    local test_GOPATH="${GOPATH%/*}"
    local candidate_version="${test_GOPATH#"${___X_CMD_PKG_POPULATE_PATH}/"*}"
    local candidate="${candidate_version%/*}"
    local version="${candidate_version#*/}"

    if [ -n "$candidate" ] && [ -n "$version" ] && [ -n "$candidate_version" ];then
        return 0
    else
        pkg:error "Test boot failed "
        return 1
    fi
}

test_go_envpath(){
    local go_version
    go_version="$( go version  | awk '{print $3}')"
    local version="${go_version#go*}"
    x path | grep -q ".x-cmd.root/local/data/pkg/populate/go/${version}/Go_package/bin" || {
        pkg:error "Test path failed"
        return 1
    }
    x path | grep -q ".x-cmd.root/local/data/pkg/populate/go/${version}/bin" || {
        pkg:error "Test path failed"
        return 1
    }
}
test_go_envpath
test_gopath_boot
