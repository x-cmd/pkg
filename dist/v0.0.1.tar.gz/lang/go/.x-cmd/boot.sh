#shellcheck shell=sh disable=SC2039,SC1090,SC3043,SC2263
___x_cmd_go_boot(){
    [ -d "$___X_CMD_PKG_INSTALL_PATH"/$name/$version/Go_package ] || mkdir -p "$___X_CMD_PKG_INSTALL_PATH/$name/$version/Go_package"
    x path add_existed_folder "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin"
    export GOPATH="$___X_CMD_PKG_INSTALL_PATH/$name/$version/Go_package"
    x mkdirp "$GOPATH/bin"
    x path add_existed_folder "$GOPATH/bin"
}
___x_cmd_go_boot
