# shellcheck shell=dash

[ "$___X_CMD_PKG___META_OS" = "darwin" ] || {
	pkg:debug "Skipping java populate for $___X_CMD_PKG___META_OS"
	return 0
}

case "$___X_CMD_PKG___META_VERSION" in
	*-open|*-sapmchn|*-trava|*-oracle|*-grl|*-gln|*-amzn|*-nik|*-tem|*-sem)
		pkg:info "Java populate. Copying " "$___X_CMD_PKG___META_TGT/Contents/Home/"* " to $___X_CMD_PKG___META_TGT"/
		x mv "$___X_CMD_PKG___META_TGT/Contents/Home/"* "$___X_CMD_PKG___META_TGT/"
		x rmrf "$___X_CMD_PKG___META_TGT/Contents"
		;;
esac