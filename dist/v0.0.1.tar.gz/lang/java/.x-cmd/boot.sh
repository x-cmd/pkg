# shellcheck shell=dash

export JAVA_HOME="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_ENV___PARSE_PKG/$___X_CMD_ENV___PARSE_VERSION"