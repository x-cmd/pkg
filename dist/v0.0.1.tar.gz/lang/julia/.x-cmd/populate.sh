# shellcheck shell=dash

if [ "$___X_CMD_WEBSRC_REGION" != "internet" ]; then
    if [ "$(x os name)" = "win" ]; then
        x mv -f "$___X_CMD_PKG___META_TGT/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.tar.gz" "$___X_CMD_PKG___META_TGT/bin/julia.exe"
    fi
else
    x uz "$___X_CMD_PKG___META_TGT/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.tar.gz" "$___X_CMD_PKG___META_TGT" 1>/dev/null || {
        pkg:error "Fail to unzip $___X_CMD_PKG_DOWNLOAD_PATH/julia/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.tar.gz" ; return 1
    }
    x mv "$___X_CMD_PKG___META_TGT/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.tar.gz" "$___X_CMD_PKG_DOWNLOAD_PATH/julia/"
fi
