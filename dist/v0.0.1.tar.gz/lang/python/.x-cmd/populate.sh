# shellcheck shell=dash
___x_cmd_pkg_python_populate(){

    case "$___X_CMD_PKG___META_VERSION" in
    pypy*)
        "$(x pkg xbin path python)" -m ensurepip
        "$(x pkg xbin path python)" -m pip install --upgrade pip
        ln -sf "$___X_CMD_PKG___META_TGT/bin/pip3" "$___X_CMD_PKG___META_TGT/bin/pip"
        return 0 ;;
    py*)
        ___x_cmd_pkg___attr "$___X_CMD_PKG___META_NAME" "$___X_CMD_PKG___META_VERSION" "$___X_CMD_PKG___META_SO/$___X_CMD_PKG___META_ARCH" download_file_ext
        local archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/$___X_CMD_PKG___META_VERSION.$download_file_ext"
        if chmod +x "${archive_path}" && "${archive_path}" -b -u -p "${archive_path%/*}" ; then
            pkg:info "Finish python $___X_CMD_PKG___META_VERSION unpack."
        else
            pkg:error "Fail to unpack python $___X_CMD_PKG___META_VERSION."; return 1
        fi
        ;;

    esac
}

___x_cmd_pkg_python_populate


