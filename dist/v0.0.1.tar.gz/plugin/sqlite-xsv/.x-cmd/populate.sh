# shellcheck shell=dash

___x_cmd___hook_sqlite_xsv_populate(){
    local archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
    if ! command -v sqlite3 >/dev/null 2>&1; then
        x env use sqlite3
    fi
    if [ "$___X_CMD_PKG___META_OS" = "win" ];then
        archive_path="$(printf "%s" "$archive_path" | sed 's/^\/c/c:/g')"
    fi
    printf "%s\n" "sqlite3 -cmd '.load $archive_path/xsv0'" > "$archive_path/sqlite-xsv.sh"
}

___x_cmd___hook_sqlite_xsv_populate