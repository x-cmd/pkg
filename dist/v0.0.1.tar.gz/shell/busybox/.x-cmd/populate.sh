# shellcheck    shell=sh            disable=SC3043,2154,2034,2155,1017
# if [ "$___X_CMD_PKG___META_OS" != "win" ]; then
#     mv "$___X_CMD_PKG___META_TGT/busybox_1.35.0-x86_64-linux-musl" "$___X_CMD_PKG___META_TGT/busybox"
#     chmod +x "$___X_CMD_PKG___META_TGT/busybox"
# else
#     mv "$___X_CMD_PKG___META_TGT/busybox_1.33-win32.exe" "$___X_CMD_PKG___META_TGT/busybox.exe"
# fi
