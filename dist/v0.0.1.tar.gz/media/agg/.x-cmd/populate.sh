# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
mkdir -p "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/agg.$___X_CMD_PKG___META_OS.$___X_CMD_PKG___META_ARCH" "$___X_CMD_PKG___META_TGT/bin/agg"
chmod +x "$___X_CMD_PKG___META_TGT/bin/agg"