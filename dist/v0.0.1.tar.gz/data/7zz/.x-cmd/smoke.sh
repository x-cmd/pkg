# shellcheck shell=dash

# check the -h

if ! 7zz -h 2>&1 ;then
    pkg:error "fail to get help"
    return 1
fi | head -n 5
