# shellcheck shell=dash
___x_cmd_pkg_osquery_populate(){
    local archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
    mkdir -p "$archive_path/bin"
    case "$___X_CMD_PKG___META_OS" in
        win)
            touch "$archive_path/bin/osqueryd.exe" "$archive_path/bin/osqueryi.exe"
            ln -sf "$archive_path/Program Files/osquery/osqueryi.exe" "$archive_path/bin/osqueryi.exe"
            ln -sf "$archive_path/Program Files/osquery/osqueryd/osqueryd.exe" "$archive_path/bin/osqueryd.exe"
            ;;
        linux)
            touch "$archive_path/bin/osqueryd" "$archive_path/bin/osqueryi" "$archive_path/bin/osqueryctl"
            ln -sf "$archive_path/opt/osquery/bin/osqueryd" "$archive_path/bin/osqueryi"
            ln -sf "$archive_path/opt/osquery/bin/osqueryd" "$archive_path/bin/osqueryd"
            ln -sf "$archive_path/opt/osquery/bin/osqueryctl" "$archive_path/bin/osqueryctl"
            ;;
        darwin)
            touch "$archive_path/bin/osqueryd" "$archive_path/bin/osqueryi" "$archive_path/bin/osqueryctl"
            ln -sf "$archive_path/opt/osquery/lib/osquery.app/Contents/MacOS/osqueryi" "$archive_path/bin/osqueryi"
            ln -sf "$archive_path/opt/osquery/lib/osquery.app/Contents/MacOS/osqueryd" "$archive_path/bin/osqueryd"
            ln -sf "$archive_path/opt/osquery/lib/osquery.app/Contents/Resources/osqueryctl" "$archive_path/bin/osqueryctl"
            ;;
    esac
}

___x_cmd_pkg_osquery_populate


