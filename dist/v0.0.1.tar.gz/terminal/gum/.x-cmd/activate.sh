___x_cmd_gum_activate(){
    if [ -f "$___X_CMD_PKG_BIN_PATH/$name" ]; then
        x rmrf "$___X_CMD_PKG_BIN_PATH/$name"
    fi
    ___x_cmd_path_unshift "$___X_CMD_PKG_POPULATE_PATH/$name/$version"
}

___x_cmd_gum_activate