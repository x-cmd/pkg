# shellcheck shell=dash
___x_cmd_pkg_vhs_populate(){
    if ! command -v ttyd >/dev/null 2>&1; then
        pkg:info "Download the dependencies ttyd for vhs"
        x env use ttyd
    fi
    if ! command -v ffmpeg >/dev/null 2>&1; then
        pkg:info "Download the dependencies ffmpeg for vhs"
        x env use ffmpeg
    fi
}

___x_cmd_pkg_vhs_populate