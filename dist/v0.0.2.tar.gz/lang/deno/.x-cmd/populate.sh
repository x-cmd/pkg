# shellcheck shell=dash

# Using deno github source (not x-cmd repack). need move to bin/deno
x mkdirp \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/bin"
x mv \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/deno" \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/bin/deno"

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.deno/bin"
