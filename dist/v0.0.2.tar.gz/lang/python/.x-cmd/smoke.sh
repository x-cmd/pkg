# shellcheck shell=dash

# check the --version
which pip
x pip --version
which pip
which python
if ! python --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi
