# shellcheck shell=dash

# check the --version

install_python(){
    local path
    path="$(cygpath -w "${___X_CMD_ROOT_DATA}")"
    echo "path: " "$path" >&2
    echo "DOWNLOAD_PATH: " "$___X_CMD_PKG_DOWNLOAD_PATH" >&2
    echo "POPULATE_PATH: " "$___X_CMD_PKG_POPULATE_PATH" >&2
    ls "/c/WINDOWS/System32/WindowsPowerShell/v1.0/"
    # /c/WINDOWS/System32/WindowsPowerShell/v1.0/PowerShell.exe "Start-Process -Wait -FilePath \"$path\pkg\download\python\py310_23.1.0-1_win_x64.exe\"  -ArgumentList \"/S /D=$path\pkg\populate\python\pypy3.9-v7.3.11\""
}
install_python

if ! python --version >&2 ;then
    pkg:error "fail to get version"
    return 1
fi
