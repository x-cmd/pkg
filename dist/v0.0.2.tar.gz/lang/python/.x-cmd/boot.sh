# shellcheck shell=dash
___x_cmd_pkg_python_boot(){

    if [ "$___X_CMD_OS_NAME_" = "win" ]; then
        export PYTHONPATH="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
        export PYTHONHOME="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
        x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/Scripts"
        x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
    else
        x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/bin"
    fi
}

___x_cmd_pkg_python_boot
