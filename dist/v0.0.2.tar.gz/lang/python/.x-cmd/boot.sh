# shellcheck shell=dash
___x_cmd_pkg_python_boot(){
    local ___X_CMD_OS_NAME_;    x os name_
    x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/Library"
    x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/include"

    if [ "$___X_CMD_OS_NAME_" = "win" ]; then
        x path add_existed_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/Scripts"
    fi
}

___x_cmd_pkg_python_boot
