# shellcheck shell=dash
___x_cmd_pkg_python_populate(){
    local download_file_ext
    ___x_cmd_pkg___attr "$___X_CMD_PKG___META_NAME" "$___X_CMD_PKG___META_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" download_file_ext
    local archive_path="$___X_CMD_PKG_DOWNLOAD_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"
    local popualte_path="$___X_CMD_PKG___META_TGT"

    case "$___X_CMD_PKG___META_VERSION" in
        pypy*)
            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
                "$popualte_path/python.exe" -m ensurepip
                "$popualte_path/python.exe" -m pip install --upgrade pip
                return 0
            else
                "$popualte_path/bin/python" -m ensurepip
                "$popualte_path/bin/python" -m pip install --upgrade pip

            fi
            ;;
        py*)

            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
                rm "$popualte_path/${___X_CMD_PKG___META_VERSION}_win_x64.exe"     #TODO:  there is a minicoda extra biniary file in the populate folder

                archive_path="$(cygpath -w "${archive_path}")"
                popualte_path="$(cygpath -w "${popualte_path}")"
                x  pwsh "Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${popualte_path}\""

                "$popualte_path/python.exe" -m ensurepip
                "$popualte_path/python.exe" -m pip install --upgrade pip --no-warn-script-location
            else
                if ! [ -f "$archive_path" ];then #TODO: REMOVE when v0.0.3 pkg released (mv to cp in xbash/pkg )
                    archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"
                fi

                if chmod +x "${archive_path}" && "${archive_path}" -b -u -p "${popualte_path}" ; then
                    pkg:info "Finish python $___X_CMD_PKG___META_VERSION unpack."
                else
                    pkg:error "Fail to unpack python $___X_CMD_PKG___META_VERSION."; return 1
                fi

            fi
            ;;
    esac
}

___x_cmd_pkg_python_populate
