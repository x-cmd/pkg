# shellcheck shell=dash
___x_cmd_pkg_python_populate(){

    case "$___X_CMD_PKG___META_VERSION" in
        pypy*)
            "$(x pkg xbin path python "$___X_CMD_PKG___META_VERSION")" -m ensurepip
            "$(x pkg xbin path python "$___X_CMD_PKG___META_VERSION")" -m pip install --upgrade pip
            ln -sf "$___X_CMD_PKG___META_TGT/bin/pip3" "$___X_CMD_PKG___META_TGT/bin/pip"
            return 0 ;;
        py*)
            local pwsh_path="/c/WINDOWS/System32/WindowsPowerShell/v1.0/PowerShell.exe"
            local tmp_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME"
            if [ "$(x os name)" = "win" ] && [ -x "$pwsh_path" ]; then
                x mkdirp "$tmp_path/tmp"
                x mv "$tmp_path/$___X_CMD_PKG___META_VERSION/${___X_CMD_PKG___META_VERSION}_win_x64.exe" "$tmp_path/tmp/${___X_CMD_PKG___META_VERSION}_win_x64.exe"
                local path;path="$(cygpath -w "${___X_CMD_ROOT_DATA}")"
                "$pwsh_path" "Start-Process -Wait -FilePath \"$path\pkg\populate\python\tmp\\${___X_CMD_PKG___META_VERSION}_win_x64.exe\"  -ArgumentList \"/S /D=$path\pkg\populate\python\\${___X_CMD_PKG___META_VERSION}\""
                x rmrf "$tmp_path/tmp"

                # echo "$(x pkg xbin path python "$___X_CMD_PKG___META_VERSION")"
                "$(x pkg xbin path python "$___X_CMD_PKG___META_VERSION")" -m ensurepip
                "$(x pkg xbin path python "$___X_CMD_PKG___META_VERSION")" -m pip install --upgrade pip --no-warn-script-location
                # ln -sf "$___X_CMD_PKG___META_TGT/Scripts/pip" "$___X_CMD_PKG___META_TGT/pip"
            else
                ___x_cmd_pkg___attr "$___X_CMD_PKG___META_NAME" "$___X_CMD_PKG___META_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" download_file_ext
                local archive_path="$tmp_path/$___X_CMD_PKG___META_VERSION/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"
                if chmod +x "${archive_path}" && "${archive_path}" -b -u -p "${archive_path%/*}" ; then
                    pkg:info "Finish python $___X_CMD_PKG___META_VERSION unpack."
                else
                    pkg:error "Fail to unpack python $___X_CMD_PKG___META_VERSION."; return 1
                fi
            fi
            ;;
    esac
}

___x_cmd_pkg_python_populate
