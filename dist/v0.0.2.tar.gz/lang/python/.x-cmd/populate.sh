# shellcheck shell=dash
x log init x_cmd_pkg

___x_cmd_pkg_python_populate(){
    # shellcheck disable=SC2034
    local PYTHONHOME="";
    # shellcheck disable=SC2034
    local PYTHONPATH="";

    local download_file_ext
    ___x_cmd_pkg___attr "$___X_CMD_PKG___META_NAME" "$___X_CMD_PKG___META_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" download_file_ext
    local archive_path="$___X_CMD_PKG_DOWNLOAD_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"
    local popualte_path="$___X_CMD_PKG___META_TGT"

    case "$___X_CMD_PKG___META_VERSION" in
        pypy*)
            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
                "$popualte_path/python.exe" -m ensurepip
                "$popualte_path/python.exe" -m pip install --upgrade pip
                return 0
            else
                "$popualte_path/bin/python" -m ensurepip
                "$popualte_path/bin/python" -m pip install --upgrade pip

            fi
            ;;
        py*)
            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then

                #TODO: remove when v0.0.3 there is a minicoda extra biniary file in the populate folder
                command rm "$popualte_path/${___X_CMD_PKG___META_VERSION}_win_x64.exe" || {
                    x_cmd_pkg:error "Remove $popualte_path/${___X_CMD_PKG___META_VERSION}_win_x64.exe failed"
                    return 1
                }

                archive_path="$(cygpath -w "${archive_path}")"
                popualte_path="$(cygpath -w "${popualte_path}")"

                x pwsh "Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${popualte_path}\"" || {
                    x_cmd_pkg:error "Fail to use powershell => Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${popualte_path}\" "
                    return 1
                }

                "$popualte_path/python.exe" -m ensurepip || {
                    x_cmd_pkg:error "ensurepip failed"
                    return 1
                }

            else
                #TODO: REMOVE when v0.0.3 pkg released (mv to cp in xbash/pkg )
                [ -f "$archive_path" ] || archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"

                command chmod +x "${archive_path}" || {
                    x_cmd_pkg:error "Fail to chmod +x ${archive_path}"
                    return 1
                }

                "${archive_path}" -b -u -p "${popualte_path}" || {
                    x_cmd_pkg:error "Fail to unpack python $___X_CMD_PKG___META_VERSION."
                    return 1
                }
            fi
            ;;
    esac

    x_cmd_pkg:info "Finish python $___X_CMD_PKG___META_VERSION unpack."
}

___x_cmd_pkg_python_populate
