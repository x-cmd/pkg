# shellcheck shell=dash

# check the --version
if [ "$(x os name)" = "darwin" ];then
    if ! lua53 -v >&2;then
        pkg:error "fail to get version"
        return 1
    fi
else
    if ! lua54 -v >&2;then
        pkg:error "fail to get version"
        return 1
    fi
fi
