# shellcheck shell=dash

export JAVA_HOME="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
