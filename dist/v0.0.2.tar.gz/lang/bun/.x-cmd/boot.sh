# shellcheck shell=dash

# Setup npm root on startup
export BUN_INSTALL="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.bun"
# Add npm global bin to path on startup
___x_cmd_path_add_folder "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.bun/bin"
