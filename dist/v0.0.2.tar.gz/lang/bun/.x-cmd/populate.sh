# shellcheck shell=dash

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/.bun/bin"
# Create manually bunx after install
command ln -s \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/bin/bun" \
    "$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION/bin/bunx" > /dev/null 2>&1 || return 0
