#shellcheck shell=sh disable=SC2039,SC1090,SC3043,SC2263
___x_cmd_perl_boot(){
    export PERL5LIB="$___X_CMD_PKG_POPULATE_PATH/$name/$version/lib:$PERL5LIB"
}
___x_cmd_perl_boot
