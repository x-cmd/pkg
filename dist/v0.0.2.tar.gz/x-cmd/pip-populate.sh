# shellcheck shell=dash
___x_cmd_pkg___pip_populate(){
(
    x env try python
    local pip_path=
    if  [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        pip_path="$___X_CMD_PKG___META_TGT/Scripts/pip"
        python -m venv "$___X_CMD_PKG___META_TGT"
    else
        pip_path="$___X_CMD_PKG___META_TGT/bin/pip"
        x python -m venv "$___X_CMD_PKG___META_TGT"
    fi
    x python -m venv "$___X_CMD_PKG___META_TGT"

    "$pip_path" install --require-virtualenv "$___X_CMD_PKG___META_NAME==$___X_CMD_PKG___META_VERSION"
)
}

___x_cmd_pkg___pip_populate


