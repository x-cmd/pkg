# shellcheck shell=dash
___x_cmd_pkg___pip_populate(){
(
    x env try python
    local venv_bin_path="$___X_CMD_PKG___META_TGT/bin"
    ! [ "$___X_CMD_PKG___META_OS" = "win" ] || venv_bin_path="$___X_CMD_PKG___META_TGT/Scripts"
    python -m venv "$___X_CMD_PKG___META_TGT"

    "$venv_bin_path/pip" install --require-virtualenv "$___X_CMD_PKG___META_NAME==$___X_CMD_PKG___META_VERSION"

    [ "$#" -gt 1 ] || return 0
    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/.x-cmd-bin"
    x mkdirp "$xcmd_bin_path"

    local source; local target
    local i; for i in "$@"; do
        if [ "$i" != "${i#*=}" ]; then
            target="$xcmd_bin_path/${i%=*}"
            source="$venv_bin_path/${i#*=}"
        else
            target="$xcmd_bin_path/$i"
            source="$venv_bin_path/$i"
        fi
        pkg:info "linking source=$source target=$target"
        ln -s -f "$source" "$target" || {
            pkg:error "ln - Operation failure source=$source target=$target"
            return 1
        }
    done
)
}
