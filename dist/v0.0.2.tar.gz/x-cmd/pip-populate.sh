# shellcheck shell=dash

x log init x_cmd_pkg

___x_cmd_pkg___pip_populate(){
    local ___X_CMD_PKG_RUNTIME_PYTHON_VERSION="py311_23.9.0-0"
    ___x_cmd_pkg___pip_populate_generate_venv || return
    ___x_cmd_pkg___pip_populate_xcmd_bin_path "$@"
}

___x_cmd_pkg___pip_populate_generate_venv(){

    # step 1: install runtime
    # ___x_cmd_pkg_runtime install python "$___X_CMD_PKG_RUNTIME_PYTHON_VERSION"  || {
    #     x_cmd_pkg:error "python install failure"
    #     return 1
    # }
    (
        x env try python

        local venv_bin_path
        venv_bin_path="$(___x_cmd_pkg___pip_venv_bin_path)"
        # step 2: install venv
        x mkdirp "$___X_CMD_PKG___META_TGT"
        # ___x_cmd_pkg_runtime_exec python="$___X_CMD_PKG_RUNTIME_PYTHON_VERSION" --
        python -m venv "$___X_CMD_PKG___META_TGT"   || {
            x_cmd_pkg:error "python -m venv $___X_CMD_PKG___META_TGT failure"
            return 1
        }

    # step 3: pip install package
       #TODO: Need to review
        ___x_cmd_pkg_runtime_getenv_ python="$___X_CMD_PKG_RUNTIME_PYTHON_VERSION"
        "$venv_bin_path/pip" install --require-virtualenv "$___X_CMD_PKG___META_NAME==$___X_CMD_PKG___META_VERSION" || {
            x_cmd_pkg:error "pip install failure"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info "pip successfully"
}

___x_cmd_pkg___pip_populate_xcmd_bin_path(){
    [ "$#" -ge 1 ] || {
        x_cmd_pkg:error "No command provided"
        return 1
    }

    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/.x-cmd-bin"
    local runtime_bin_path="$___X_CMD_PKG_RUNTIME_POPULATE_PATH/python/$___X_CMD_PKG_RUNTIME_PYTHON_VERSION/bin" #TODO: shims
    [ "$___X_CMD_PKG___META_OS" != "win" ] || runtime_bin_path="$___X_CMD_PKG_RUNTIME_POPULATE_PATH/python/$___X_CMD_PKG_RUNTIME_PYTHON_VERSION/Scripts" #TODO: shims

    x mkdirp "$xcmd_bin_path"

    local venv_bin_path
    venv_bin_path="$(___x_cmd_pkg___pip_venv_bin_path)"

    # TODO: use shim to instead
    local source; local target
    local i; for i in "$@"; do
        target="$xcmd_bin_path/$i"
        source="$venv_bin_path/$i"
        x_cmd_pkg:info "linking source=$source target=$target"
        printf "%s" "#!/bin/sh
            export PATH=\"$runtime_bin_path:\$PATH\"
            \"$source\" \"\$@\"
" > "$xcmd_bin_path/$i"
        command chmod +x "$xcmd_bin_path/$i"
    done


}

___x_cmd_pkg___pip_venv_bin_path(){
    local venv_bin_path
    if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        venv_bin_path="$___X_CMD_PKG___META_TGT/Scripts"
    else
        venv_bin_path="$___X_CMD_PKG___META_TGT/bin"
    fi
    x_cmd_pkg:info "venv_bin_path => $venv_bin_path"
    printf "%s" "$venv_bin_path"
}
