# shellcheck shell=dash

x log init x_cmd_pkg

___x_cmd_pkg___npm_populate(){
    local ___X_CMD_PKG_RUNTIME_NODE_VERSION="v19.0.0"
    ___x_cmd_pkg___npm_populate_install_prefix || return
    ___x_cmd_pkg___npm_populate_xcmd_bin_path "$@"
}

___x_cmd_pkg___npm_populate_install_prefix(){

    # ___x_cmd_pkg_runtime install node "$___X_CMD_PKG_RUNTIME_NODE_VERSION" || {
    #     x_cmd_pkg:error "install node failure"
    #     return 1
    # }

    (
        x env try node

        # ___x_cmd_pkg_runtime_exec  node="$___X_CMD_PKG_RUNTIME_NODE_VERSION" -- \
            npm install --prefix "$___X_CMD_PKG___META_TGT" "$___X_CMD_PKG___META_NAME@$___X_CMD_PKG___META_VERSION"   || {
            x_cmd_pkg:error "npm install $___X_CMD_PKG___META_NAME"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info  "npm runtime successfully"
}

___x_cmd_pkg___npm_populate_xcmd_bin_path(){
    [ "$#" -ge 1 ] || return 1
    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/.x-cmd-bin"
    x mkdirp "$xcmd_bin_path"

    local node_bin_path="$___X_CMD_PKG___META_TGT/node_modules/.bin"
    local runtime_bin_path="$___X_CMD_PKG_RUNTIME_POPULATE_PATH/node/$___X_CMD_PKG_RUNTIME_NODE_VERSION/bin" #TODO: shims
    x_cmd_pkg:info "runtime_bin_path: $runtime_bin_path"

    # TODO: use shim to instead
    local source; local target
    local i; for i in "$@"; do
        target="$xcmd_bin_path/$i"
        source="$node_bin_path/$i"

        x_cmd_pkg:info "linking source=$source target=$target"
        printf "%s" "#!/bin/sh
            export PATH=\"$runtime_bin_path:\$PATH\"
            \"$source\" \"\$@\"
" > "$xcmd_bin_path/$i"
        command chmod +x "$xcmd_bin_path/$i"
    done
}
