# shellcheck shell=dash disable=SC2120
___x_cmd_pkg___npm_populate(){
(
    ___X_CMD_PKG_RUNTIME_NODE_VERSION="v18.18.0"
    local runtime_populate_path="$___X_CMD_PKG_RUNTIME_POPULATE_PATH/node/$___X_CMD_PKG_RUNTIME_NODE_VERSION"
    local populate_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
    ___x_cmd_pkg_runtime install node "$___X_CMD_PKG_RUNTIME_NODE_VERSION" || return
    ___x_cmd_pkg_addpath node "$___X_CMD_PKG_RUNTIME_NODE_VERSION" "" "$runtime_populate_path" || return
    command npm install --prefix "$populate_path" "$___X_CMD_PKG___META_NAME@$___X_CMD_PKG___META_VERSION"

    local xcmd_bin_path="$populate_path/.x-cmd-bin/${1}"
    x ensurefp "$xcmd_bin_path"

    printf "%s" "
        export PATH=\"$___X_CMD_PKG_RUNTIME_POPULATE_PATH/node/$___X_CMD_PKG_RUNTIME_NODE_VERSION/bin:\$PATH\"
        $populate_path/node_modules/.bin/${1} \"\$@\"
" > "$xcmd_bin_path"

    command chmod +x "$xcmd_bin_path"
)
}
