# shellcheck shell=dash
___x_cmd_pkg___npm_populate(){
(
    x env try node
    x mkdirp "$___X_CMD_PKG___META_TGT"
    x npm install --prefix "$___X_CMD_PKG___META_TGT" "$___X_CMD_PKG___META_NAME@$___X_CMD_PKG___META_VERSION"
)
}
