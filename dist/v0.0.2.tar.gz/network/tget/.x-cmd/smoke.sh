# shellcheck shell=dash

if ! tget --version 2>&1;then
    pkg:error "in2csv  fail to get version"
    return 1
fi