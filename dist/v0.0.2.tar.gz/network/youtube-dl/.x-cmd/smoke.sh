# shellcheck shell=dash

if ! youtube-dl --version 2>&1;then
    pkg:error "in2csv  fail to get version"
    return 1
fi

x env remove youtube-dl