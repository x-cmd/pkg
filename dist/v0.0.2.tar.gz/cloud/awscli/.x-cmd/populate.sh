# shellcheck    shell=dash

# TODO: remove this file in v0.0.3
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/pip-populate.sh"

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg___pip_populate  awscli=aws.cmd aws
else
    ___x_cmd_pkg___pip_populate  awscli=aws aws
fi
