# shellcheck    shell=dash
x env try python
___x_cmd_pkg___pip_populate
