# shellcheck    shell=dash



___x_cmd_pkg___npm_populate
