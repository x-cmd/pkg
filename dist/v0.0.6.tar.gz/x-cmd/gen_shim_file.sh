# shellcheck    shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_shim_gen(){
    local source="$___X_CMD_PKG___META_TGT"; local x_=
    local default_target="$___X_CMD_PKG___META_TGT/shim_bin"
    local adaptive_target="$___X_CMD_PKG___META_TGT/adaptive_shim_bin"

    local mode=; local code=; local env_var=; local target=
    while [ $# -gt 0 ]; do
        case "$1" in
            --mode)     mode=$2;                shift 2 ;;
            --code)     code=$2;                shift 2 ;;
            --var)
                        if [ -z "$env_var" ]; then
                            env_var="$2"
                        else
                            env_var="$env_var $2";
                        fi
                        shift 2
                        ;;
            --bin_dir)
                source="$___X_CMD_PKG___META_TGT/${2}"
                ! [ "${source%/*}" = "${source%?}" ] || source="$___X_CMD_PKG___META_TGT"
                shift 2 ;;
            --bin_file) shift 1;                break ;;
            *)                                  return 1 ;;
        esac
    done

    x mkdirp  "$default_target"
    ! [ "$mode" = "adaptive" ] || x mkdirp  "$adaptive_target"
    x_cmd_pkg:info --source "$source/" --shim_bin "$default_target/" --adaptive_shim_bin "$adaptive_target/"  "shim gen"
    local i; for i in "$@"; do

        [ -f "$source/$i" ] || {
            x_cmd_pkg:error "Not found: [$source/$i]"
            return 1
        }

        if [ "$i" != "${i%.exe*}" ] && [ "$code" = "bat" ]; then
            target="${i%.exe*}.bat"
        elif [ "$i" != "${i%.exe*}" ] && [ "$code" = "sh" ]; then
            target="${i%".exe"*}"
        else
            target="$i"
        fi
        target="${target##*/}"

        case "$code" in
            bat)
                ___x_cmd_shim__gen_batcode_local  "$env_var"  -- "$source/$i" > "$default_target/$target" || return ;;

            sh)
                ___x_cmd_shim__gen_shcode_local  "$env_var"  -- "$source/$i" > "$default_target/$target" || return ;;
        esac
        command chmod +x  "$source/$i" "$default_target/$target"

        if [ "$mode" = "adaptive" ]; then
            case "$code" in
                bat)
                    ___x_cmd_shim__gen_batcode_varset "$env_var"  -- "$source/$i" > "$adaptive_target/$target" || return ;;

                sh)
                    ___x_cmd_shim__gen_shcode_varset "$env_var"  -- "$source/$i" > "$adaptive_target/$target" || return  ;;
            esac
            command chmod +x "$adaptive_target/$target"
        fi
    done
}


