# shellcheck    shell=dash 
if ! pdfminer --version 2>&1;then
  pkg:error "fail to get version"
  return 1
fi
