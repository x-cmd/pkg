
# shellcheck    shell=sh
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/mdtsql.exe" "$___X_CMD_PKG___META_TGT/bin/mdtsql.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/mdtsql" "$___X_CMD_PKG___META_TGT/bin/mdtsql"
fi

