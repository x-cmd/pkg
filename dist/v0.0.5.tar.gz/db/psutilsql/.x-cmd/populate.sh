
# shellcheck    shell=sh
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/psutilsql.exe" "$___X_CMD_PKG___META_TGT/bin/psutilsql.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/psutilsql" "$___X_CMD_PKG___META_TGT/bin/psutilsql"
fi

