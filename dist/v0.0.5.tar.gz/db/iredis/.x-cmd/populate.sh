# shellcheck    shell=dash 
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/pip-populate.sh"
___x_cmd_pkg___pip_populate iredis
