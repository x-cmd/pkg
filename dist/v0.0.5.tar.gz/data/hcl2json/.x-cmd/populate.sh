
# shellcheck    shell=dash
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/hcl2json.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"   "$___X_CMD_PKG___META_TGT/bin/hcl2json.exe"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/hcl2json.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/hcl2json.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"        "$___X_CMD_PKG___META_TGT/bin/hcl2json"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/hcl2json"
fi
