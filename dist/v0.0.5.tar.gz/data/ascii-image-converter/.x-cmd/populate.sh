# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
x mkdirp "$___X_CMD_PKG___META_TGT/bin"

if [ "$___X_CMD_PKG___META_OS" = "win" ] ; then
    local x_=;  x fsiter --dir1_
    local zipname="$x_"
    x mv  "$___X_CMD_PKG___META_TGT/$zipname/ascii-image-converter.exe"         "$___X_CMD_PKG___META_TGT/bin/ascii-image-converter.exe"
else
    x mv  "$___X_CMD_PKG___META_TGT/$zipname/ascii-image-converter"             "$___X_CMD_PKG___META_TGT/bin/ascii-image-converter"
fi
