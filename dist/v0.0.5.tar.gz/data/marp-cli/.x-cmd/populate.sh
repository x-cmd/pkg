# shellcheck    shell=dash
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"
___x_cmd_pkg___npm_populate_install(){
    local pkg_install_name="@marp-team/marp-cli"
    npm install                                          \
        --prefix "$___X_CMD_PKG___META_TGT"              \
        "$pkg_install_name@$___X_CMD_PKG___META_VERSION" \
    || return 1
}
___x_cmd_pkg___npm_populate marp
