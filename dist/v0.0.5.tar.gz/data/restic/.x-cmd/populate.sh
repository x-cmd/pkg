
# shellcheck    shell=sh
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/restic.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"       "$___X_CMD_PKG___META_TGT/bin/restic.exe"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/restic.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/restic.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"        "$___X_CMD_PKG___META_TGT/bin/restic"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/restic"
fi

