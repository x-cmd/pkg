
# shellcheck    shell=dash
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/ytt.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"   "$___X_CMD_PKG___META_TGT/bin/ytt.exe"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/ytt.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/ytt.${___X_CMD_PKG___META_OS}.${___X_CMD_PKG___META_ARCH}"        "$___X_CMD_PKG___META_TGT/bin/ytt"
    chmod +x "$___X_CMD_PKG___META_TGT/bin/ytt"
fi
