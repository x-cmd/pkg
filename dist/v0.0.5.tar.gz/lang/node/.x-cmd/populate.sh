# shellcheck shell=dash

# Ensure npm root after install
x log init x_cmd_pkg
xrc shim

x mkdirp \
    "$___X_CMD_PKG___META_TGT/.npm/lib" \
    "$___X_CMD_PKG___META_TGT/.npm/bin"


. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/gen_shim_file.sh"

___x_cmd_pkg_node_populate(){

    if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        ___x_cmd_pkg_shim_gen --mode app --code bat --var "NPM_CONFIG_PREFIX=$___X_CMD_PKG___META_TGT/.npm" --bin_dir "" --bin_file corepack.cmd install_tools.bat nodevars.bat npm.cmd npx.cmd node.exe || return
        ___x_cmd_pkg_shim_gen --mode app --code sh --var "NPM_CONFIG_PREFIX=$___X_CMD_PKG___META_TGT/.npm" --bin_dir "" --bin_file corepack npm npx node.exe || return
    else
        ___x_cmd_pkg_shim_gen --mode app --code sh --var "NPM_CONFIG_PREFIX=$___X_CMD_PKG___META_TGT/.npm" --bin_dir "bin" --bin_file corepack npm npx node || return
    fi

}

___x_cmd_pkg_node_populate


