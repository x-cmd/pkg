# shellcheck    shell=dash
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/pip-populate.sh"

___x_cmd_pkg___pip_populate_install_dep(){
    local bin_dir="$1"
    "$___X_CMD_PKG___META_TGT/$bin_dir/pip" install --require-virtualenv 'httpx[socks]' || {
        x_cmd_pkg:error "pip install failure"
        return 1
    }
}

___x_cmd_pkg___pip_populate interpreter
