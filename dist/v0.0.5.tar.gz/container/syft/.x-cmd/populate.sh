
# shellcheck    shell=sh
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/syft.exe" "$___X_CMD_PKG___META_TGT/bin/syft.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/syft" "$___X_CMD_PKG___META_TGT/bin/syft"
fi

