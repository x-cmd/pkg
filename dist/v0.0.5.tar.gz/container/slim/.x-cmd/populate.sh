
# shellcheck    shell=sh
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = win ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/slim.exe"           "$___X_CMD_PKG___META_TGT/bin/slim.exe"
    x mv  "$___X_CMD_PKG___META_TGT/slim-sensor.exe"    "$___X_CMD_PKG___META_TGT/bin/slim-sensor.exe"
    x mv  "$___X_CMD_PKG___META_TGT/docker-slim.exe"    "$___X_CMD_PKG___META_TGT/bin/docker-slim.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/slim"                "$___X_CMD_PKG___META_TGT/bin/slim"
    x mv "$___X_CMD_PKG___META_TGT/slim-sensor"         "$___X_CMD_PKG___META_TGT/bin/slim-sensor"
    x mv "$___X_CMD_PKG___META_TGT/docker-slim"         "$___X_CMD_PKG___META_TGT/bin/docker-slim"
fi

