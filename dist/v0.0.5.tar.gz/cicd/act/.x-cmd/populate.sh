# shellcheck    shell=sh            disable=SC3043,2154,2034,2155
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
if [ "$___X_CMD_PKG___META_OS" = "win" ] ; then
    x mv  "$___X_CMD_PKG___META_TGT/act.exe" "$___X_CMD_PKG___META_TGT/bin/act.exe"
else
    x mv "$___X_CMD_PKG___META_TGT/act" "$___X_CMD_PKG___META_TGT/bin/act"
fi
