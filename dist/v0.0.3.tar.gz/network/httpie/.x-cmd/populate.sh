# shellcheck    shell=dash

# TODO: remove this file in v0.0.3

___x_cmd_pkg_httpie_populate(){
    local dependency_python="Miniconda3-py311_23.9.0-0"


    . "$___X_CMD_PKG_METADATA_PATH/.x-cmd/pip-populate.sh"
    ___x_cmd_pkg___pip_populate  "$dependency_python"  http httpie https || return
    ___x_cmd_pkg_gen_pip_dependency_file "python=$dependency_python"

}

___x_cmd_pkg_httpie_populate || return



