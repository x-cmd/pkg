# shellcheck    shell=dash


___x_cmd_pkg_tget_populate(){
    local dependency_python="v18.18.0"

    . "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"

    ___x_cmd_pkg___npm_populate "$dependency_python" tget || return
    ___x_cmd_pkg_gen_npm_dependency_file  "node=$dependency_python"


}
___x_cmd_pkg_tget_populate || return

