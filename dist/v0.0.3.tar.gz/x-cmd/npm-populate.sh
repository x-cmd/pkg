# shellcheck shell=dash

x log init x_cmd_pkg

___x_cmd_pkg___npm_populate()(
    local ___X_CMD_PKG_RUNTIME_NODE_VERSION="$1"; shift
    ___x_cmd_pkg___npm_populate_install_prefix || return
    ___x_cmd_pkg___npm_populate_xcmd_bin_path "$@"
)

___x_cmd_pkg___npm_populate_install_prefix(){

    # step 1: install runtime
     x_cmd_pkg:info "Set up node environment: $___X_CMD_PKG_RUNTIME_NODE_VERSION" || {
        x_cmd_pkg:error "Node install failure"
        return 1
    }


    (
        x_cmd_pkg:info "Set up Node environment: $___X_CMD_PKG_RUNTIME_NODE_VERSION"
        x env try "node=${___X_CMD_PKG_RUNTIME_NODE_VERSION}" || return

        # ___x_cmd_pkg_runtime_exec  node="$___X_CMD_PKG_RUNTIME_NODE_VERSION" -- \
            npm install --prefix "$___X_CMD_PKG___META_TGT" "$___X_CMD_PKG___META_NAME@$___X_CMD_PKG___META_VERSION"   || {
            x_cmd_pkg:error "npm install $___X_CMD_PKG___META_NAME"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info  "npm runtime successfully"
}

___x_cmd_pkg___npm_populate_xcmd_bin_path(){
    [ "$#" -ge 1 ] || return 1
    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/.x-cmd-bin"
    x mkdirp "$xcmd_bin_path"

    local node_bin_path="$___X_CMD_PKG___META_TGT/node_modules/.bin"
    local runtime_bin_path="$___X_CMD_PKG_ROOT_SPHERE/$___X_CMD_PKG___META_SPHERE_VERSION/populate/node/$___X_CMD_PKG_RUNTIME_NODE_VERSION/bin" #TODO: shims
    x_cmd_pkg:info "runtime_bin_path: $runtime_bin_path"

    # TODO: use shim to instead
    local source; local target
    local i; for i in "$@"; do
        target="$xcmd_bin_path/$i"
        source="$node_bin_path/$i"

        x_cmd_pkg:info --source "$source" "--target" $target
        printf "%s" "#!/bin/sh
            export PATH=\"$runtime_bin_path:\$PATH\"
            \"$source\" \"\$@\"
" > "$xcmd_bin_path/$i"
        command chmod +x "$xcmd_bin_path/$i"
    done
}


___x_cmd_pkg_gen_npm_dependency_file(){
    [ "$#" -ge 1 ] || return 0
    local name=
    local version=
    local dendency_yml_path=

    dendency_yml_path="$___X_CMD_PKG___META_DEPENDENCY_PATH/${___X_CMD_PKG___META_NAME}_${___X_CMD_PKG___META_VERSION}.yml"
    x touch "$dendency_yml_path"
    local i; for i in "$@"; do
        version="${i#*=}"
        name=${i%=*}
        printf "%s: %s\n" "$name" "$version" > "$dendency_yml_path"
    done

}

