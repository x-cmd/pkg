# shellcheck shell=dash

# Using deno github source (not x-cmd repack). need move to bin/deno
x mkdirp \
    "$___X_CMD_PKG___META_TGT/bin"
x mv \
    "$___X_CMD_PKG___META_TGT/deno" \
    "$___X_CMD_PKG___META_TGT/bin/deno"

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.deno/bin"
