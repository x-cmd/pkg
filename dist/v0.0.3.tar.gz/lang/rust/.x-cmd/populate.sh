# shellcheck shell=dash

(
    if ! x cd "$___X_CMD_PKG___META_TGT"; then
        pkg:warn "can't enter into $___X_CMD_PKG___META_TGT"
        return 1
    fi
    ./install.sh --destdir="../$___X_CMD_PKG___META_VERSION/" --prefix=/
)
