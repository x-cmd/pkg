# shellcheck    shell=dash

# TODO: remove this file in v0.0.3

___x_cmd_pkg_tsnode_populate(){
    local dependency_python="v18.18.0"

    . "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"
    ___x_cmd_pkg___npm_populate "$dependency_python" ts-node ts-node-cwd ts-node-esm ts-node-script ts-node-transpile-only ts-script || return
    ___x_cmd_pkg_gen_npm_dependency_file "node=$dependency_python"


}
___x_cmd_pkg_tsnode_populate || return



