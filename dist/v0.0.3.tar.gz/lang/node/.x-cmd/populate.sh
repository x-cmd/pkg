# shellcheck shell=dash

# Ensure npm root after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.npm/lib" \
    "$___X_CMD_PKG___META_TGT/.npm/bin"
