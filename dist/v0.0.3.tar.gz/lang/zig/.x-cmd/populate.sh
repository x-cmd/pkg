# shellcheck    shell=dash
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
x mv "$___X_CMD_PKG___META_TGT/zig" "$___X_CMD_PKG___META_TGT/bin/zig"
