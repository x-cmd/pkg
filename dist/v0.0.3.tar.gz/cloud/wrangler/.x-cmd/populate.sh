# shellcheck    shell=dash

___x_cmd_pkg_wrangler_populate(){
    local dependency_node="v18.18.0"


    . "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"
    ___x_cmd_pkg___npm_populate  "$dependency_node" wrangler wrangler2 || return
    ___x_cmd_pkg_gen_npm_dependency_file "node=$dependency_node"
}

___x_cmd_pkg_wrangler_populate || return
