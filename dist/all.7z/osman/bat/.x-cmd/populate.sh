mkdir -p "$tgt/bin"
local os="${osarch%/*}";  local arch="${osarch#*/}"
mv "$tgt/bat.$os.$arch" "$tgt/bin/bat"
