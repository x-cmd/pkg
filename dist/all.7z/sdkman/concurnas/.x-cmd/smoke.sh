# shellcheck shell=dash

# check the --version
x pkg install java 14.0.2
x env try java=14.0.2
concurnas << EOF
/exit
EOF
if ! [ $? -eq 0 ] ;then
    pkg:error "fail to get version"
    return 1
fi