# shellcheck shell=dash

# check the --version
x env try java
if ! mybatis_migrations --help >&2 ;then
    pkg:error "fail to get version"
    return 1
fi