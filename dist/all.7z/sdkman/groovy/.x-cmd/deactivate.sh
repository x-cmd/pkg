___x_cmd_groovy_deactivate(){
    x path rm "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin"
}

___x_cmd_groovy_deactivate
