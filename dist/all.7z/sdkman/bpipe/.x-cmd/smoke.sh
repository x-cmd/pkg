# shellcheck shell=dash

# check the --version
x pkg install java 17.0.2
x env try java=17.0.2
if ! bpipe --version 2>&1;then
    pkg:error "fail to get version"
    return 1
fi