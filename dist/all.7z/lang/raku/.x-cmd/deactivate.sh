___x_cmd_raku_deactivate(){
    x path rm "$___X_CMD_PKG_INSTALL_PATH/$name/$version/bin"
    x path rm "$___X_CMD_PKG_INSTALL_PATH/$name/$version/share/perl6/site/bin"
}

___x_cmd_raku_deactivate
