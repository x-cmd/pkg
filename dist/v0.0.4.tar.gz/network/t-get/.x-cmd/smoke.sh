# shellcheck shell=dash

# if ! tget 'magnet:?xt=urn:btih:ee789f4487726336ef65b4f061ce2744ca624ceb&dn=Distributed+Node.+Js:+Building+Enterprise-Ready+Backend+Services+By+Thomas+Hunter+II+EPUB&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451&tr=udp%3A%2F%2Ftracker.moeking.me%3A6969&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969&tr=udp%3A%2F%2Fopen.tracker.cl%3A1337&tr=udp%3A%2F%2Fexodus.desync.com%3A6969' 2>&1;then
#     pkg:error "fail to get version"
#     return 1
# fi
return 1