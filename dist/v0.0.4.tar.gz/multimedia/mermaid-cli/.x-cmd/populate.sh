# shellcheck    shell=dash
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"

___x_cmd_pkg___npm_populate_install_prefix(){

    # step 1: install runtime
    x_cmd_pkg:info "Set up node environment: $___X_CMD_PKG_RUNTIME_NODE_VERSION"

    (
        x env try "node=${___X_CMD_PKG_RUNTIME_NODE_VERSION}" || return

        # ___x_cmd_pkg_runtime_exec  node="$___X_CMD_PKG_RUNTIME_NODE_VERSION" -- \
            npm install --prefix "$___X_CMD_PKG___META_TGT" "@mermaid-js/mermaid-cli@$___X_CMD_PKG___META_VERSION"   || {
            x_cmd_pkg:error "npm install @mermaid-js/mermaid-cli"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info  "npm runtime successfully"
}

___x_cmd_pkg___npm_populate mmdc browsers extract-zip js-yaml
