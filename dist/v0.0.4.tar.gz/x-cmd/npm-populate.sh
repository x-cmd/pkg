# shellcheck shell=dash

x log init x_cmd_pkg

___x_cmd_pkg___npm_populate()(

    local ___X_CMD_PKG_RUNTIME_NODE_VERSION="v18.18.0"
    local op="$1";
    case "$op" in
        --node_version)
            shift 1; ___X_CMD_PKG_RUNTIME_NODE_VERSION="$1"; shift 1;;
    esac

    log:sub:init -i "$___X_CMD_PKG___META_NAME $___X_CMD_PKG___META_VERSION" x_cmd_pkg "npm populate"
    ___x_cmd_pkg___npm_populate_install_prefix      || return
    ___x_cmd_pkg___npm_populate_xcmd_bin_path "$@"  || return
    ___x_cmd_pkg_gen_npm_dependency_file "$___X_CMD_PKG___META_DEPENDENCY_CONTENT" || return
    log:sub:fini
)

___x_cmd_pkg___npm_populate_install_prefix(){

    # step 1: install runtime
    x_cmd_pkg:info "Set up node environment: $___X_CMD_PKG_RUNTIME_NODE_VERSION"

    (
        x pkg addpath node "${___X_CMD_PKG_RUNTIME_NODE_VERSION}"
        x pkg boot node "${___X_CMD_PKG_RUNTIME_NODE_VERSION}"

        npm install --prefix "$___X_CMD_PKG___META_TGT" "$___X_CMD_PKG___META_NAME@$___X_CMD_PKG___META_VERSION"   || {
            x_cmd_pkg:error "npm install $___X_CMD_PKG___META_NAME"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info  "npm runtime successfully"
}

___x_cmd_pkg___npm_populate_xcmd_bin_path(){
    [ "$#" -ge 1 ] || return 1
    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$xcmd_bin_path"

    local node_bin_path="$___X_CMD_PKG___META_TGT/node_modules/.bin"
    local x_treename=; ___x_cmd_pkg_treename_ node "$___X_CMD_PKG_RUNTIME_NODE_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" || return
    local runtime_bin_path="$___X_CMD_PKG_ROOT_SPHERE/$___X_CMD_PKG___META_SPHERE_NAME/$x_treename/node/$___X_CMD_PKG_RUNTIME_NODE_VERSION/bin" #TODO: shims
    x_cmd_pkg:info "runtime_bin_path: $runtime_bin_path"

    # TODO: use shim to instead
    local source; local x_
    local i; for i in "$@"; do
        source="$node_bin_path/$i"

        x_cmd_pkg:info --source "$source"


        if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
            ___x_cmd_batcode_local_ "PATH=$runtime_bin_path:\$PATH" -- "${source}.exe" || return
            printf "%s\n" "$x_" > "$xcmd_bin_path/${i}.bat"
            ___x_cmd_shcode_local_ "PATH=$runtime_bin_path:\$PATH" -- "$source" || return
            printf "%s\n"  "$x_" > "$xcmd_bin_path/$i"
        else
            ___x_cmd_shcode_local_ "PATH=$runtime_bin_path:\$PATH" -- "$source"
            printf "%s\n" "$x_" > "$xcmd_bin_path/$i"
        fi
        command chmod +x "$xcmd_bin_path/$i"
    done
}


___x_cmd_pkg_gen_npm_dependency_file(){
    [ "$#" -ge 1 ] || return 0

    [ -f "$___X_CMD_PKG___META_DEPENDENCY_FILE" ] || x touch "$___X_CMD_PKG___META_DEPENDENCY_FILE"
    printf "%s\n" "$*" > "$___X_CMD_PKG___META_DEPENDENCY_FILE"

}

