# shellcheck shell=dash

x log init x_cmd_pkg

___x_cmd_pkg___pip_populate()(
    local ___X_CMD_PKG_RUNTIME_PYTHON_VERSION="Miniconda3-py311_23.9.0-0"
    local op="$1";
    case "$op" in
        --python_version)
            shift 1; ___X_CMD_PKG_RUNTIME_PYTHON_VERSION="$1"; shift 1;;
    esac

    log:sub:init -i "$___X_CMD_PKG___META_NAME $___X_CMD_PKG___META_VERSION" x_cmd_pkg "pip populate"
    ___x_cmd_pkg___pip_populate_generate_venv       || return
    ___x_cmd_pkg___pip_populate_xcmd_bin_path "$@"  || return
    ___x_cmd_pkg_gen_pip_dependency_file  "$___X_CMD_PKG___META_DEPENDENCY_CONTENT" || return
    log:sub:fini
)

___x_cmd_pkg___pip_populate_generate_venv(){

    x_cmd_pkg:info "step 1/3, Set up python environment: $___X_CMD_PKG_RUNTIME_PYTHON_VERSION"
    (
        x pkg boot python "$___X_CMD_PKG_RUNTIME_PYTHON_VERSION" #1>&2 2>/dev/null

        local venv_bin_path
        venv_bin_path="$(___x_cmd_pkg___pip_venv_bin_path)"
        x mkdirp "$___X_CMD_PKG___META_TGT"
        x_cmd_pkg:info "step 2/3, python -m venv $___X_CMD_PKG___META_TGT"
        python -m venv "$___X_CMD_PKG___META_TGT"   || {
            x_cmd_pkg:error "python -m venv $___X_CMD_PKG___META_TGT failure"
            return 1
        }

        x_cmd_pkg:info "step 3/3, pip install package $___X_CMD_PKG___META_NAME==$___X_CMD_PKG___META_VERSION"
        "$venv_bin_path/pip" install --require-virtualenv "$___X_CMD_PKG___META_NAME==$___X_CMD_PKG___META_VERSION" || {
            x_cmd_pkg:error "pip install failure"
            return 1
        }
    ) || return 1
    x_cmd_pkg:info "pip successfully"
}

___x_cmd_pkg___pip_populate_xcmd_bin_path(){
    [ "$#" -ge 1 ] || N=x-cmd-pkg M="Provide command" log:ret:1

    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/shim_bin"
    local x_treename=; ___x_cmd_pkg_treename_ python "$___X_CMD_PKG_RUNTIME_PYTHON_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" || return
    local python_populate_dir="$___X_CMD_PKG_ROOT_SPHERE/$___X_CMD_PKG___META_SPHERE_NAME/$x_treename/python/$___X_CMD_PKG_RUNTIME_PYTHON_VERSION"
    local python_bin_path="$python_populate_dir/bin"
    [ "$___X_CMD_PKG___META_OS" != "win" ] || python_bin_path="$python_populate_dir/Scripts"

    [ -d "$python_bin_path" ] || N=x-cmd-pkg M="Not found dir $python_bin_path" log:ret:1

    x mkdirp "$xcmd_bin_path"

    local venv_bin_path
    venv_bin_path="$(___x_cmd_pkg___pip_venv_bin_path)"

    # TODO: use shim to instead
    local source=; local x_=
    local i; for i in "$@"; do
        source="$venv_bin_path/$i"
        x_cmd_pkg:info --source "$source"

       if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
            ___x_cmd_batcode_local_ "PATH=$python_bin_path:\$PATH" -- "${source}.exe" || return
            printf "%s\n" "$x_" > "$xcmd_bin_path/${i}.bat"
            ___x_cmd_shcode_local_ "PATH=$python_bin_path:\$PATH" -- "$source" || return
            printf "%s %s %s\n" "PYTHONHOME=$python_populate_dir" "PYTHONPATH=$python_populate_dir" "$x_" > "$xcmd_bin_path/$i"
        else
            ___x_cmd_shcode_local_ "PATH=$python_bin_path:\$PATH" -- "$source" || return
            printf "%s\n" "$x_" > "$xcmd_bin_path/$i"
        fi

        command chmod +x "$xcmd_bin_path/$i"
    done


}

___x_cmd_pkg___pip_venv_bin_path(){
    local venv_bin_path
    if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        venv_bin_path="$___X_CMD_PKG___META_TGT/Scripts"
    else
        venv_bin_path="$___X_CMD_PKG___META_TGT/bin"
    fi
    x_cmd_pkg:info "venv_bin_path => $venv_bin_path"
    printf "%s" "$venv_bin_path"
}


___x_cmd_pkg_gen_pip_dependency_file(){
    [ "$#" -ge 1 ] || return 0

    [ -f "$___X_CMD_PKG___META_DEPENDENCY_FILE" ] || x touch "$___X_CMD_PKG___META_DEPENDENCY_FILE"
    printf "%s\n" "$*" > "$___X_CMD_PKG___META_DEPENDENCY_FILE"
}
