#shellcheck shell=dash

___x_cmd_pkg_go_populate(){
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"
    source="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$target" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "$source/$i => $i"
        ___x_cmd_shim__gen_"$op"code_local  "GOPATH=$___X_CMD_PKG___META_TGT/Go_package"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
    log:sub:fini
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_go_populate bat go.exe gofmt.exe || return
fi

___x_cmd_pkg_go_populate sh go gofmt || return