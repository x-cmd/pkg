#shellcheck shell=dash

export GOPATH="$___X_CMD_PKG___META_TGT/Go_package"
x mkdirp "$___X_CMD_PKG___META_TGT/bin"
___x_cmd_path_add_existed_folder "$___X_CMD_PKG___META_TGT/bin"
___x_cmd_path_add_existed_folder "$GOPATH/bin"
