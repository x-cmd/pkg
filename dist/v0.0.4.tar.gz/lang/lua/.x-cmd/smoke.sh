# shellcheck shell=dash

# check the --version
x os name_
if [ "$___X_CMD_OS_NAME_" = "darwin" ];then
    if ! lua53 -v >&2;then
        pkg:error "fail to get version"
        return 1
    fi
else
    if ! lua54 -v >&2;then
        pkg:error "fail to get version"
        return 1
    fi
fi
