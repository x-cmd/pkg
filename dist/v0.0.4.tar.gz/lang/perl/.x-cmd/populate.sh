# shellcheck shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_perl_shim(){
    local op="$1"; shift
    local shim_path="$___X_CMD_PKG___META_TGT/shim-bin"
    local source="$___X_CMD_PKG___META_TGT/perl/bin"
    x mkdirp "$shim_path"

    [ "$___X_CMD_PKG___META_OS" = "win" ] || source="$___X_CMD_PKG___META_TGT/bin"
    x_cmd_pkg:info --source "$source" --shim-bin "$shim_path" "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "Generating shim-bin/$i"
        ___x_cmd_shim__gen_"$op"code_local  "PERL5LIB=$___X_CMD_PKG___META_TGT/lib:$PERL5LIB"   -- "$source/$i" > "$shim_path/$i" || return
        command chmod +x "$shim_path/$i"
    done
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_perl_shim bat perl.exe || return
fi
___x_cmd_pkg_perl_shim sh perl || return
