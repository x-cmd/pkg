# shellcheck shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_perl_shim(){
    local op="$1"; shift
    local shim_path="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$shim_path"

    local populate_path="$___X_CMD_PKG___META_TGT/perl/bin"
    [ "$___X_CMD_PKG___META_OS" = "win" ] || populate_path="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$shim_path" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$populate_path/$i" ] || return
        x_cmd_pkg:info "$populate_path/$i => $i"
        ___x_cmd_shim__gen_"$op"code_local  "PERL5LIB=$___X_CMD_PKG___META_TGT/lib:$PERL5LIB"   -- "$populate_path/$i" > "$shim_path/$i" || return
        command chmod +x "$shim_path/$i"
    done
    log:sub:fini
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_perl_shim bat perl.exe || return
fi
___x_cmd_pkg_perl_shim sh perl || return
