# shellcheck shell=dash

# Ensure npm root after install
x log init x_cmd_pkg
xrc shim

x mkdirp \
    "$___X_CMD_PKG___META_TGT/.npm/lib" \
    "$___X_CMD_PKG___META_TGT/.npm/bin"


___x_cmd_pkg_node_populate(){
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"
    local source="$___X_CMD_PKG___META_TGT"
    [ "$___X_CMD_PKG___META_OS" = "win" ] || source="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$target" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "$source/$i => $i"
        ___x_cmd_shim__gen_"$op"code_local  "PATH=$___X_CMD_PKG___META_TGT/.npm/bin:\$PATH"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
    log:sub:fini
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_node_populate bat corepack.cmd install_tools.bat nodevars.bat npm.cmd npx.cmd || return
    ___x_cmd_pkg_node_populate sh corepack npm npx node.exe || return
else
    ___x_cmd_pkg_node_populate sh corepack npm npx node || return
fi


