# shellcheck shell=dash

# Setup npm root on startup
export NPM_CONFIG_PREFIX="$___X_CMD_PKG___META_TGT/.npm"
___x_cmd_path_add_folder "$NPM_CONFIG_PREFIX/bin"
