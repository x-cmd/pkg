# shellcheck shell=dash

# Setup npm root on startup


if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    export NPM_CONFIG_PREFIX="$___X_CMD_PKG___META_TGT/.npm/bin"
    ___x_cmd_path_add_existed_folder "$___X_CMD_PKG___META_TGT/.npm/bin"
else
    export NPM_CONFIG_PREFIX="$___X_CMD_PKG___META_TGT/.npm"
    ___x_cmd_path_add_existed_folder "$___X_CMD_PKG___META_TGT/bin"
    ___x_cmd_path_add_existed_folder "$NPM_CONFIG_PREFIX/bin"
fi
