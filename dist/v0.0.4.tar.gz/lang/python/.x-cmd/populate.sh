# shellcheck shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_python_populate(){
    # shellcheck disable=SC2034
    local PYTHONHOME="";
    # shellcheck disable=SC2034
    local PYTHONPATH="";

    local download_file_ext
    ___x_cmd_pkg___attr "$___X_CMD_PKG___META_NAME" "$___X_CMD_PKG___META_VERSION" "$___X_CMD_PKG___META_OS/$___X_CMD_PKG___META_ARCH" download_file_ext
    local archive_path="$___X_CMD_PKG_DOWNLOAD_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"
    local populate_path="$___X_CMD_PKG___META_TGT"

    case "$___X_CMD_PKG___META_VERSION" in
        pypy*)
            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
                "$populate_path/python.exe" -m ensurepip
                "$populate_path/python.exe" -m pip install --upgrade pip
                return 0
            else
                "$populate_path/bin/python" -m ensurepip
                "$populate_path/bin/python" -m pip install --upgrade pip
            fi
            ;;
        Miniconda3*)
            if [ "$___X_CMD_PKG___META_OS" = "win" ]; then

                local tmp_populate_path="$populate_path"
                archive_path="$(cygpath -w "${archive_path}")"
                tmp_populate_path="$(cygpath -w "${populate_path}")"
                x:debug "Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${tmp_populate_path}\""
                x pwsh "Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${tmp_populate_path}\"" || {
                    x_cmd_pkg:error "Fail to use powershell => Start-Process -Wait -FilePath \"${archive_path}\"  -ArgumentList \"/S /D=${tmp_populate_path}\" "
                    return 1
                }

                "$populate_path/python.exe" -m ensurepip || {
                    x_cmd_pkg:error "ensurepip failed"
                    return 1
                }

            else
                #TODO: REMOVE when v0.0.3 pkg released (mv to cp in xbash/pkg )
                [ -f "$archive_path" ] || archive_path="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/${___X_CMD_PKG___META_VERSION}/${___X_CMD_PKG___META_VERSION}_${___X_CMD_PKG___META_OS}_${___X_CMD_PKG___META_ARCH}.$download_file_ext"

                command chmod +x "${archive_path}" || {
                    x_cmd_pkg:error "Fail to chmod +x ${archive_path}"
                    return 1
                }

                "${archive_path}" -b -u -p "${populate_path}" || {
                    x_cmd_pkg:error "Fail to unpack python $___X_CMD_PKG___META_VERSION."
                    return 1
                }
            fi
            ;;
    esac

    x_cmd_pkg:info "Finish python $___X_CMD_PKG___META_VERSION unpack."
}

___x_cmd_pkg_python_shim(){
    local shim_path="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$shim_path"

    local populate_path="$___X_CMD_PKG___META_TGT"
    [ "$___X_CMD_PKG___META_OS" = "win" ] || populate_path="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$shim_path" x_cmd_pkg "shim gen bat/sh code"
    local i; for i in "$@"; do
        [ -f "$populate_path/$i" ] || return
        x_cmd_pkg:info "$populate_path/$i => $i"
        if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
            ___x_cmd_shim__gen_batcode_local  "PYTHONPATH=$___X_CMD_PKG___META_TGT" "PYTHONHOME=$___X_CMD_PKG___META_TGT"  -- "$populate_path/$i" > "$shim_path/$i" || return
        fi
        ___x_cmd_shim__gen_shcode_local  "PYTHONPATH=$___X_CMD_PKG___META_TGT" "PYTHONHOME=$___X_CMD_PKG___META_TGT"   -- "$populate_path/$i" > "$shim_path/$i" || return

        command chmod +x "$shim_path/$i"
    done
    log:sub:fini
}
export PYTHONPATH="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"
        export PYTHONHOME="$___X_CMD_PKG_POPULATE_PATH/$___X_CMD_PKG___META_NAME/$___X_CMD_PKG___META_VERSION"

___x_cmd_pkg_python_populate || return

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_python_shim python.exe || return
else
    ___x_cmd_pkg_python_shim python pip pip3 || return
fi

