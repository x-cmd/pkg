# shellcheck shell=dash

unset PYTHONPATH="$___X_CMD_PKG___META_TGT"
unset PYTHONHOME="$PYTHONPATH"
___x_cmd_path_rm "$PYTHONPATH/Scripts"
___x_cmd_path_rm "$PYTHONPATH"
