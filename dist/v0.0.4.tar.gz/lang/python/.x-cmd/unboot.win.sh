# shellcheck shell=dash

[ -z "$PYTHONHOME" ] || unset PYTHONHOME
[ -z "$PYTHONPATH" ] || {
    ___x_cmd_path_rm "$PYTHONPATH/Scripts"
    ___x_cmd_path_rm "$PYTHONPATH"
    unset PYTHONPATH
}
