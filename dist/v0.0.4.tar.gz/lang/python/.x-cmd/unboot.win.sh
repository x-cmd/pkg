# shellcheck shell=dash

[ -z "$PYTHONPATH" ] || unset $PYTHONPATH
[ -n "$PYTHONHOME" ] || unset $PYTHONHOME

___x_cmd_path_rm "$PYTHONPATH/Scripts"
___x_cmd_path_rm "$PYTHONPATH"
