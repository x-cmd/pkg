# shellcheck shell=dash

export PYTHONPATH="$___X_CMD_PKG___META_TGT"
export PYTHONHOME="$PYTHONPATH"
___x_cmd_path_add_existed_folder "$PYTHONPATH/Scripts"
___x_cmd_path_add_existed_folder "$PYTHONPATH"
