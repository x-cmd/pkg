# shellcheck shell=dash

# Using deno github source (not x-cmd repack). need move to bin/deno
x mkdirp \
    "$___X_CMD_PKG___META_TGT/bin"
x mv \
    "$___X_CMD_PKG___META_TGT/deno" \
    "$___X_CMD_PKG___META_TGT/bin/deno"

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.deno/bin"

___x_cmd_pkg_deno_populate(){
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"
    local source="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$target" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "$source/$i => $i"
        ___x_cmd_shim__gen_"$op"code_local  "DENO_INSTALL_ROOT=$___X_CMD_PKG___META_TGT/.deno"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
    log:sub:fini
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_deno_populate bat deno.exe || return
fi


___x_cmd_pkg_deno_populate sh deno || return
