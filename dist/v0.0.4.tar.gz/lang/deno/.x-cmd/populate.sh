# shellcheck shell=dash
x log init x_cmd_pkg
# Using deno github source (not x-cmd repack). need move to bin/deno
x mkdirp \
    "$___X_CMD_PKG___META_TGT/bin"
x mv \
    "$___X_CMD_PKG___META_TGT/deno" \
    "$___X_CMD_PKG___META_TGT/bin/deno"

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.deno/bin"



. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/gen_shim_file.sh"

___x_cmd_pkg_deno_populate(){
    if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        ___x_cmd_pkg_shim_gen --mode app --code bat --var "DENO_INSTALL_ROOT=$___X_CMD_PKG___META_TGT/.deno" --bin_dir bin --bin_file deno.exe || return
        ___x_cmd_pkg_shim_gen --mode app --code sh  --var "DENO_INSTALL_ROOT=$___X_CMD_PKG___META_TGT/.deno" --bin_dir bin --bin_file deno.exe || return
    else
        ___x_cmd_pkg_shim_gen --mode app --code sh  --var "DENO_INSTALL_ROOT=$___X_CMD_PKG___META_TGT/.deno"  --bin_dir bin --bin_file deno || return
    fi

}

___x_cmd_pkg_deno_populate

