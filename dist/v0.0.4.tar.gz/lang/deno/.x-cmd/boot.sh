# shellcheck shell=dash

# Setup npm root on startup
export DENO_INSTALL_ROOT="$___X_CMD_PKG___META_TGT/.deno"
# Add npm global bin to path on startup
___x_cmd_path_add_existed_folder "$___X_CMD_PKG___META_TGT/.deno/bin"


