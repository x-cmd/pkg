# shellcheck shell=dash

# Setup npm root on startup
export BUN_INSTALL="$___X_CMD_PKG___META_TGT/.bun"
# Add npm global bin to path on startup
___x_cmd_path_add_existed_folder "$___X_CMD_PKG___META_TGT/.bun/bin"
