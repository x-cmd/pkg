# shellcheck shell=dash
x log init x_cmd_pkg
# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.bun/bin"
# Create manually bunx after install
command ln -s \
    "$___X_CMD_PKG___META_TGT/bin/bun" \
    "$___X_CMD_PKG___META_TGT/bin/bunx" > /dev/null 2>&1 || return 0

___x_cmd_pkg_bun_populate(){
    xrc shim
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"
    local source="$___X_CMD_PKG___META_TGT/bin"
    x_cmd_pkg:info --source "$source" --shim-bin "$target" "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "Generating shim-bin/$i"
        ___x_cmd_shim__gen_"$op"code_local  "BUN_INSTALL=$___X_CMD_PKG___META_TGT/.bun"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
}


___x_cmd_pkg_bun_populate sh bun bunx || return


