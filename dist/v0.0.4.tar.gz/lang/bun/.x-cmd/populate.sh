# shellcheck shell=dash

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.bun/bin"
# Create manually bunx after install
command ln -s \
    "$___X_CMD_PKG___META_TGT/bin/bun" \
    "$___X_CMD_PKG___META_TGT/bin/bunx" > /dev/null 2>&1 || return 0
