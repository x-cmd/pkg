# shellcheck shell=dash

# Ensure deno install root and deno bin after install
x mkdirp \
    "$___X_CMD_PKG___META_TGT/.bun/bin"
# Create manually bunx after install
command ln -s \
    "$___X_CMD_PKG___META_TGT/bin/bun" \
    "$___X_CMD_PKG___META_TGT/bin/bunx" > /dev/null 2>&1 || return 0

___x_cmd_pkg_bun_populate(){
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"
    local source="$___X_CMD_PKG___META_TGT/bin"
    log:sub:init -i "$target" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "$source/$i => $i"
        ___x_cmd_shim__gen_"$op"code_local  "BUN_INSTALL=$___X_CMD_PKG___META_TGT/.bun"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
    log:sub:fini
}


___x_cmd_pkg_bun_populate sh bun bunx || return


