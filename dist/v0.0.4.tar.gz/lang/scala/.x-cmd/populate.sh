# shellcheck    shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_scala_populate(){
    local op="$1"; shift
    local source=
    local target="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$target"

    log:sub:init -i "$target" x_cmd_pkg "shim gen ${op} code"
    local i; for i in "$@"; do
        source="$___X_CMD_PKG___META_TGT/bin/$i"
        x_cmd_pkg:info "$source => $i"
        [ -f "$source" ] || return
        ___x_cmd_shim__gen_"$op"code_local "JAVA_HOME=\${JAVA_HOME:-$___X_CMD_PKG_ROOT_SPHERE/X/tree/java/18.0.2-sem}"  -- "$source" > "$target/$i" || return
        command chmod +x "$target/$i" "$source"
    done
    log:sub:fini
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_scala_populate bat common.bat scala.bat scalac.bat scaladoc.bat || return
fi

___x_cmd_pkg_scala_populate sh common scala scalac scaladoc || return


