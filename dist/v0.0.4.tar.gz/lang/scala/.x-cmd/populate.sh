# shellcheck    shell=sh
x log init x_cmd_pkg

___x_cmd_pkg_scala_populate(){
    local x_=
    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$xcmd_bin_path"
    local i; for i in "$@"; do
    target="$___X_CMD_PKG___META_TGT/shim-bin"
    source="$___X_CMD_PKG___META_TGT/bin/$i"
    x_cmd_pkg:info --source "$source" "--target" $target

    local xcmd_bin_path="$___X_CMD_PKG___META_TGT/shim-bin"

    if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
        ___x_cmd_shim_gen_bat_stable "JAVA_HOME=\${JAVA_HOME:-\$___X_CMD_PKG_ROOT_SPHERE/X/java/18.0.2-sem}" -- $source
        printf "%s" "$x_" > "$xcmd_bin_path/$i"
    else
        ___x_cmd_shim_gen_sh_stable "JAVA_HOME=\${JAVA_HOME:-\$___X_CMD_PKG_ROOT_SPHERE/X/java/18.0.2-sem}"  -- $source
         printf "%s" "$x_" > "$xcmd_bin_path/$i"
    fi

    command chmod +x "$target/$i"
    done

    [ -n "$JAVA_HOME" ] || x env use java=18.0.2-sem
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_scala_populate common.bat scala.bat scalac.bat scaladoc.bat
else
    ___x_cmd_pkg_scala_populate common scala scalac scaladoc
fi