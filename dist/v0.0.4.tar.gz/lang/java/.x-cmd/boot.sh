# shellcheck shell=dash
___x_cmd_path_add_folder "$___X_CMD_PKG___META_TGT/bin"
export JAVA_HOME="$___X_CMD_PKG___META_TGT"
