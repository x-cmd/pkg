# shellcheck shell=dash
x log init x_cmd_pkg
xrc shim



___x_cmd_pkg_java_populate(){
    [ "$___X_CMD_PKG___META_OS" = "darwin" ] || {
        pkg:debug "Skipping java populate for $___X_CMD_PKG___META_OS"
        return 0
    }

    case "$___X_CMD_PKG___META_VERSION" in
        *-open|*-sapmchn|*-trava|*-oracle|*-grl|*-gln|*-amzn|*-nik|*-tem|*-sem)
            pkg:info "Java populate. Copying " "$___X_CMD_PKG___META_TGT/Contents/Home/"* " to $___X_CMD_PKG___META_TGT"/
            x mv "$___X_CMD_PKG___META_TGT/Contents/Home/"* "$___X_CMD_PKG___META_TGT/"
            x rmrf "$___X_CMD_PKG___META_TGT/Contents"
            ;;
    esac

}

___x_cmd_pkg_java_populate

___x_cmd_pkg_java_shim(){
    local op="$1"; shift
    local shim_path="$___X_CMD_PKG___META_TGT/shim_bin"
    local source="$___X_CMD_PKG___META_TGT"
    local target=

    x mkdirp "$shim_path"

    x_cmd_pkg:info --source "$source" --shim_bin "$shim_path" "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "Generating shim_bin/$i"
        if [ "$i" != "${i%.exe*}" ] && [ "$op" = "bat" ]; then
            target="${i%.exe*}.bat"
        elif [ "$i" != "${i%.exe*}" ] && [ "$op" = "sh" ]; then
            target="${i%".exe"*}"
        else
            target="$i"
        fi
        target="${target##*/}"

        ___x_cmd_shim__gen_"$op"code_local  "JAVAHOME=$___X_CMD_PKG___META_TGT" -- "$source/$i" > "$shim_path/$target" || return
        command chmod +x "${shim_path}/${target}"
    done

}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_java_shim bat bin/java.exe bin/javac.exe  || return
    ___x_cmd_pkg_java_shim sh bin/java.exe bin/javac.exe || return
else
    ___x_cmd_pkg_java_shim sh bin/java bin/javac || return
fi



