# shellcheck shell=dash
x log init x_cmd_pkg
xrc shim

___x_cmd_pkg_java_shim(){
    local op="$1"; shift
    local shim_path="$___X_CMD_PKG___META_TGT/shim-bin"
    x mkdirp "$shim_path"

	if [ "$___X_CMD_PKG___META_OS" = "darwin" ]; then
		case "$___X_CMD_PKG___META_VERSION" in
			*-open|*-sapmchn|*-trava|*-oracle|*-grl|*-gln|*-amzn|*-nik|*-tem|*-sem)
				pkg:info "Java populate. Copying " "$___X_CMD_PKG___META_TGT/Contents/Home/"* " to $___X_CMD_PKG___META_TGT"/
				x mv "$___X_CMD_PKG___META_TGT/Contents/Home/"* "$___X_CMD_PKG___META_TGT/"
				x rmrf "$___X_CMD_PKG___META_TGT/Contents"
				;;
		esac
	fi

    local populate_path="$___X_CMD_PKG___META_TGT"
    [ "$___X_CMD_PKG___META_OS" = "win" ] || populate_path="$___X_CMD_PKG___META_TGT/bin"
    x_cmd_pkg:info --source "$populate_path" --shim-bin "$shim_path" "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$populate_path/$i" ] || return
        x_cmd_pkg:info "Generating shim-bin/$i"
        ___x_cmd_shim__gen_"$op"code_local  "JAVA_HOME=$___X_CMD_PKG___META_TGT"   -- "$populate_path/$i" > "$shim_path/$i" || return
        command chmod +x "$shim_path/$i"
    done
}

if [ "$___X_CMD_PKG___META_OS" = "win" ]; then
    ___x_cmd_pkg_java_shim bat java javac || return
fi
___x_cmd_pkg_java_shim sh java javac || return


