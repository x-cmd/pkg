# shellcheck    shell=dash 
. "$___X_CMD_PKG_METADATA_PATH/.x-cmd/npm-populate.sh"
___x_cmd_pkg___npm_populate czg
