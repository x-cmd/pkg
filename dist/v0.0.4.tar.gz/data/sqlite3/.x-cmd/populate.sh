# shellcheck shell=dash

___x_cmd_pkg_node_populate(){
    local op="$1"; shift
    local target="$___X_CMD_PKG___META_TGT/shim_bin"
    x mkdirp "$target"
    local source="$___X_CMD_PKG___META_TGT"
    [ "$___X_CMD_PKG___META_OS" = "win" ] || source="$___X_CMD_PKG___META_TGT/bin"
    x_cmd_pkg:info --source "$source" --shim_bin "$target" "shim gen ${op} code"
    local i; for i in "$@"; do
        [ -f "$source/$i" ] || return
        x_cmd_pkg:info "Generating shim_bin/$i"
        ___x_cmd_shim__gen_"$op"code_local  "PATH=$___X_CMD_PKG___META_TGT/.npm/bin:\$PATH"  -- "$source/$i" > "$target/$i" || return
        command chmod +x "$target/$i"
    done
}